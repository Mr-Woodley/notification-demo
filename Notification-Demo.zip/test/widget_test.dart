import 'package:flutter_test/flutter_test.dart';

void main() {
  test('dummy test', () {
    expect(1 + 1, 2);
  });
}
