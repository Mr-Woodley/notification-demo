import 'package:flutter/material.dart';
import '../services/notification_service.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final service = NotificationService();

    return Scaffold(
      appBar: AppBar(title: const Text("Notification Demo")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: () => service.showImmediateNotification(),
              child: const Text("Immediate Notification"),
            ),
            const Text("Sa voye yon notifikasyon imedyatman."),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => service.showScheduledNotification(),
              child: const Text("Scheduled Notification"),
            ),
            const Text("Sa pwograme yon notifikasyon pou pita."),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => service.showRepeatingNotification(),
              child: const Text("Repeating Notification"),
            ),
            const Text("Sa repete notifikasyon an chak minit."),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => service.showBigTextNotification(),
              child: const Text("Big Text Notification"),
            ),
            const Text("Sa montre yon notifikasyon ak tèks long."),
          ],
        ),
      ),
    );
  }
}
