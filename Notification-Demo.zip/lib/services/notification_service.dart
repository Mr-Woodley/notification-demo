import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    // Inisyalize timezone
    tz.initializeTimeZones();

    const AndroidInitializationSettings androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initSettings =
        InitializationSettings(android: androidInit);
    await flutterLocalNotificationsPlugin.initialize(initSettings);
  }

  Future<void> showImmediateNotification() async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails('channelId', 'channelName',
            importance: Importance.high, priority: Priority.high);
    const NotificationDetails details =
        NotificationDetails(android: androidDetails);
    await flutterLocalNotificationsPlugin.show(
        0, 'Imedya', 'Notifikasyon imedyatman', details);
  }

  Future<void> showScheduledNotification() async {
    await flutterLocalNotificationsPlugin.zonedSchedule(
      1,
      'Pwograme',
      'Notifikasyon apre 5 segond',
      tz.TZDateTime.now(tz.local).add(const Duration(seconds: 5)), // ✅ korije
      const NotificationDetails(
        android: AndroidNotificationDetails('channelId', 'channelName'),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> showRepeatingNotification() async {
    await flutterLocalNotificationsPlugin.periodicallyShow(
      2,
      'Repete',
      'Notifikasyon chak minit',
      RepeatInterval.everyMinute,
      const NotificationDetails(
        android: AndroidNotificationDetails('channelId', 'channelName'),
      ),
    );
  }

  Future<void> showBigTextNotification() async {
    const BigTextStyleInformation bigTextStyleInformation =
        BigTextStyleInformation(
      'Sa se yon notifikasyon ak anpil tèks pou montre kijan li fonksyone.',
    );
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails('channelId', 'channelName',
            styleInformation: bigTextStyleInformation);
    const NotificationDetails details =
        NotificationDetails(android: androidDetails);
    await flutterLocalNotificationsPlugin.show(
        3, 'Big Text', 'Notifikasyon ak tèks long', details);
  }
}
